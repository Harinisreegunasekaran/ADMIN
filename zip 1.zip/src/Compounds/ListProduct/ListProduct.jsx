import React from 'react'
import './ListProduct.css'
const ListProduct = () => {
  return (
    <div className='list-product'>

    </div>
  )
}

export default ListProduct